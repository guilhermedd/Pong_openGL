# Pong_openGL
Pong Made in openGL

to run:
    ```
    make
    ```

Right:

- Press "w" to go up
- Press "s" to go down

TODO:
- Menu para escolher a dificuldade
- IA para jogar o jogo
- Fazer o jogo em 3D
- Fazer o jogo rodar com as setas

